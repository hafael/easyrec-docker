easyrec 1.0
-----------

Thank you for downloading easyrec!

To get started please check out the easyrec installation guide at:
	https://sourceforge.net/p/easyrec/wiki/Installation%20Guide/

Please make sure you adjust the MySQL configuration to ensure 
good performance of easyrec. You can find recommended settings at:
	https://sourceforge.net/p/easyrec/wiki/Installation%20Guide/#configuring-mysql

You can find more information about easyrec at:
	http://www.easyrec.org

easyrec is published and distributed via SourceForge.
The official project page can be found at:
	https://sourceforge.net/projects/easyrec/

For information on how to install and run easyrec, please refer to our wiki:
	https://sourceforge.net/p/easyrec/wiki/Home/

If you encounter problems, have any questions or suggestions, please have
a look at our forum at:
	https://sourceforge.net/p/easyrec/forum/

You find news about the project via
* blog: https://sourceforge.net/p/easyrec/blog/
* facebook: https://www.facebook.com/pages/easyrec/112083432158656
* twitter: https://twitter.com/easyrec
	
The easyrec team

May 2016
Research Studios Austria - Smart Agent Technologies